#create To Do file, write data to file, close file
todo = open("ToDo.txt", "w")

todo.write("Clean House,low \n")
todo.write("Pay Bills,high \n")

todo.close()

#------------------------------------------------#
#Open file in read mode & create dictionary
todo = open("ToDo.txt","r")

tplTable = []
for row in todo:
    strData = row.split(",")
    dicRow = {"Task": strData[0], "Priority": strData[1].strip(" \n")}
    tplTable.append(dicRow)
todo.close()

print("-------------------------------------------")

#Menu
while(True):
    print()
    print(
        '''Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program''')
    print()
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    #Option 1
    if (strChoice.strip() == '1'):
        print()
        for line in tplTable:
            print(line["Task"] + ": " + line["Priority"])
    #Option 2
    if (strChoice.strip() == '2'):
        print()
        strNewTask = str(input("What is the new task? "))
        strNewPriority = str(input("What is the new task's priority? "))
        dicNewRow = {"Task" : strNewTask,"Priority" : strNewPriority}
        tplTable.append(dicNewRow)
    #Option 3
    if (strChoice.strip() == '3'):
        print()
        strRemove = str(input("Which task do you want to remove? "))
        i = 0
        blnValue = False
        while(i < len(tplTable)):
            dicRemove = tplTable[i]
            if(strRemove == (dicRemove["Task"])):
                del tplTable[i]
                for line in tplTable:
                    print(line["Task"] + ": " + line["Priority"])
                blnValue = True
                break
            i += 1
        if(blnValue == False):
            print("Please try again and type the task you want to remove ")
    #Option 4
    if (strChoice.strip() == '4'):
        print()
        print("The following list:")
        print()
        for line in tplTable:
            print(line["Task"] + ": " + line["Priority"])
        print()
        print("was saved to a file")
        todo = open("ToDo.txt", "w")
        for list in tplTable:
            todo.write(list["Task"] + "," + list["Priority"] + "\n")
    #Option 5
    if (strChoice.strip() == '5'):
        print()
        print("Exiting program, your list will be saved")
        print("The following list:")
        print()
        for line in tplTable:
            print(line["Task"] + ": " + line["Priority"])
        print()
        print("was saved to a file")
        todo = open("ToDo.txt", "w")
        for list in tplTable:
            todo.write(list["Task"] + "," + list["Priority"] + "\n")
        break




